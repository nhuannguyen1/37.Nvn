class hlstr:
    def __init__(self,strtohl = ""):
        self.strtohl = strtohl
        self.controller = controller
    