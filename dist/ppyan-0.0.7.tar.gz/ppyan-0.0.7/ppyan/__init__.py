from pynvn.csv.todict import dictFcsv_2col_eval_list,dict_str_from_lcsv,dict_from_csv2col
from pynvn.list.flist import filter_lstr