from pynvn.data.hdata import returnvaluelist,grouper,duprowdata
